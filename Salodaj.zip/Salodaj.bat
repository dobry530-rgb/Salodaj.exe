@echo off 

start cmd.exe
start cmd.exe
start cmd.exe

start Salodaj.exe