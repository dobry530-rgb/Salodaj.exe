█████   ████    █        ████    ████    ████      █
█        █    █   █       █      █  █    █  █     █    █
  █      █████   █       █      █  █    █  █████     █
    █    █    █   █       █      █  █    █  █     █    █
████    █    █   █████   ████     ███   █     █    █
                                                       █ █    
                                      
Creator: Dobry530

Language: C++

Level destruction: 0/10



GDI ONLY